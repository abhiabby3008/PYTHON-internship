from tkinter import *
from tkinter import messagebox
import sqlite3 as sql
# Define an empty list to store tasks
tasks = []

# Function to display the to-do list
def display_tasks():
    if not tasks:
        task_list.delete(1.0, END)
        task_list.insert(END, "Your to-do list is empty.")
    else:
        task_list.delete(1.0, END)
        task_list.insert(END, "To-Do List:\n")
        for i, task in enumerate(tasks, start=1):
            status = "Done" if task["completed"] else "Not Done"
            task_list.insert(END, f"{i}. {task['task']} ({status})\n")

# Function to add a task to the to-do list
def add_task():
    task_name = task_entry.get()
    if task_name:
        task = {"task": task_name, "completed": False}
        tasks.append(task)
        display_tasks()
        task_entry.delete(0, END)
    else:
        task_list.delete(1.0, END)
        task_list.insert(END, "Task name cannot be empty.")

# Function to mark a task as completed
def mark_completed():
    try:
        task_number = int(task_entry.get())
        if 1 <= task_number <= len(tasks):
            tasks[task_number - 1]["completed"] = True
            display_tasks()
            task_entry.delete(0, END)
        else:
            task_list.delete(1.0, END)
            task_list.insert(END, "Invalid task number. Please enter a valid task number.")
    except ValueError:
        task_list.delete(1.0, END)
        task_list.insert(END, "Please enter a valid task number.")

# Function to remove a task from the to-do list
def remove_task():
    try:
        task_number = int(task_entry.get())
        if 1 <= task_number <= len(tasks):
            removed_task = tasks.pop(task_number - 1)
            display_tasks()
            task_entry.delete(0, END)
        else:
            task_list.delete(1.0, END)
            task_list.insert(END, "Invalid task number. Please enter a valid task number.")
    except ValueError:
        task_list.delete(1.0, END)
        task_list.insert(END, "Please enter a valid task number.")

# Function to exit the application
def exit_app():
    root.destroy()

# Main GUI window
root = Tk()
root.title("To-Do List GUI")
root.geometry("380x300")

# GUI components
task_entry = Entry(root,width=35,)
task_entry.grid(row=0, column=0, pady=5, padx=5,columnspan=2)

add_button = Button(root, text="Add Task", command=add_task, width=13,font=("arial", "10"),bg='#83E0F2')
add_button.grid(row=0, column=2, pady=5, padx=5)

display_button = Button(root, text="Display List", command=display_tasks, width=13, font=("arial", "10"),bg='#83E0F2')
display_button.grid(row=1, column=0, pady=5, padx=5)

mark_button = Button(root, text="Mark Completed", command=mark_completed, width=13, font=("arial", "10"),bg='#83E0F2')
mark_button.grid(row=1, column=1, pady=5, padx=5)

remove_button = Button(root, text="Remove Task", command=remove_task, width=13, font=("arial", "10"),bg='#83E0F2')
remove_button.grid(row=1, column=2, pady=5, padx=5)

task_list = Text(root, height=10, width=40, wrap=WORD)
task_list.grid(row=2, column=0, columnspan=3, pady=10, padx=10)

quit_button = Button(root, text="Exit", command=exit_app, width=13, font=("arial", "10"),bg='#83E0F2')
quit_button.grid(row=4, column=0, pady=10, padx=10, columnspan=3)

root.mainloop()
