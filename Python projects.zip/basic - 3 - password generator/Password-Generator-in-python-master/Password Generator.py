import random
import string
from tkinter import *

def generate_password(pw_length):
    alphabet = string.ascii_lowercase
    symbols = string.punctuation
    digits = string.digits
    uppercase = string.ascii_uppercase

    # Use all character classes in the password
    password = random.choice(uppercase) + random.choice(digits) + random.choice(symbols)
    
    # Fill the rest of the password with a mix of characters
    for _ in range(pw_length - 3):
        character_class = random.choice([alphabet, symbols, digits, uppercase])
        password += random.choice(character_class)

    # Shuffle the password to randomize the order
    password_list = list(password)
    random.shuffle(password_list)
    password = ''.join(password_list)

    return password

def generate_passwords(num_passwords, password_lengths):
    passwords = []
    for _ in range(num_passwords):
        password = generate_password(random.choice(password_lengths))
        passwords.append(password)
    return passwords

def generate_passwords_gui():
    def generate_passwords_callback():
        result_text.delete(1.0, END)  # Clear previous results
        num_passwords = int(num_passwords_entry.get())
        password_lengths_str = lengths_entry.get().split(',')
        password_lengths = [max(3, int(length)) for length in password_lengths_str]
        passwords = generate_passwords(num_passwords, password_lengths)
        for i, password in enumerate(passwords):
            result_text.insert(END, f"Password #{i+1}: {password}\n")

    root = Tk()
    root.title("Password Generator")
    root.geometry("500x400")
    root.configure(bg="#EFEFEF")

    num_passwords_label = Label(root, text="Number of Passwords:")
    lengths_label = Label(root, text="Enter Password Lengths (Minimum 3, separated by commas):")

    num_passwords_entry = Entry(root)
    lengths_entry = Entry(root)

    result_text = Text(root, wrap=WORD, height=10, width=40)
    scrollbar = Scrollbar(root, command=result_text.yview)

    generate_button = Button(root, text="Generate Passwords", command=generate_passwords_callback, bg="#83E0F2")

    # Grid Layout
    num_passwords_label.grid(row=0, column=0, padx=10, pady=5, sticky=W)
    num_passwords_entry.grid(row=0, column=1, padx=10, pady=5, sticky=W)

    lengths_label.grid(row=1, column=0, padx=10, pady=5, sticky=W)
    lengths_entry.grid(row=1, column=1, padx=10, pady=5, sticky=W)

    generate_button.grid(row=2, column=0, columnspan=2, pady=10)

    result_text.grid(row=3, column=0, columnspan=2, padx=10, pady=10, sticky=W + E + N + S)
    scrollbar.grid(row=3, column=2, sticky=N + S)

    result_text.config(yscrollcommand=scrollbar.set)

    root.mainloop()

if __name__ == "__main__":
    generate_passwords_gui()
